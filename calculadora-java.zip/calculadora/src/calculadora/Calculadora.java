package calculadora;

import java.util.Scanner;

public class Calculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("#########################################");
		System.out.println("############## Ola humano! ############## ");
		System.out.println("#########################################");
		System.out.println("");
		
		
		boolean continua = true;
		
		while(continua) {
			System.out.println("Digite a opercacao que deseja calcular:");
			System.out.println("1 -> ADICAO");
			System.out.println("2 -> SUBTRACAO");
			System.out.println("3 -> DIVISAO");
			System.out.println("4 -> MULTIPLICACAO");
			
			Scanner scan = new Scanner(System.in);
			
			Integer operacao = scan.nextInt();
			String oper = "";
			
			switch(operacao) {
				case 1:
					oper = "ADICAO";
					break;
				case 2:
					oper = "SUBTRACAO";
					break;
				case 3:
					oper = "DIVISAO";
					break;
				case 4:
					oper = "MULTIPLICACAO";
					break;
			}
			
			System.out.printf("Você escolheu %s! Agora digite quantos numeros você deseja calcular.\n", oper);
			
			Integer numeros = scan.nextInt();
			int count = 1;
			int numeroAnterior = 0;
			int numeroAtual = 0;
			
			while(count <= numeros) {
				System.out.printf("Digite o numero %d\n", count);
				
				numeroAtual = scan.nextInt();
				
				if(count == 1) {
					numeroAnterior = numeroAtual;
				}else {
					if(operacao == 1)
						numeroAnterior = numeroAnterior + numeroAtual;
					else if(operacao == 2)
						numeroAnterior = numeroAnterior - numeroAtual;
					else if(operacao == 3)
						numeroAnterior = numeroAnterior / numeroAtual;
					else if(operacao == 4)
						numeroAnterior = numeroAnterior * numeroAtual;
				}	
				
				count++;
			}
			
			System.out.printf("Resultado %d\n", numeroAnterior);
			System.out.println("Deseja continuar com outra operacao? (1 = Sim; 0 = Nao)");
			
			continua = scan.nextInt() == 1;
		}
	}

}
